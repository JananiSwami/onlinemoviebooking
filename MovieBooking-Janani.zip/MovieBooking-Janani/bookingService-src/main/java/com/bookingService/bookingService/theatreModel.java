package com.bookingService.bookingService;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "theatre")
public class theatreModel {
	@Id
	private String theatrename;
	private String location;
	private int seatcapacity;
	private float rating;
	private float price;

	public theatreModel() {
	}

	public theatreModel(String theatrename, int seatcapacity, String location, String cast, float rating) {
		super();
		this.theatrename = theatrename;
		this.seatcapacity = seatcapacity;
		this.location = location;
		this.rating = rating;
	}

	
	public String getTheatrename() {
		return theatrename;
	}

	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}

	public int getseatcapacity() {
		return seatcapacity;
	}

	public void setseatcapacity(int seatcapacity) {
		this.seatcapacity = seatcapacity;
	}

	public String getlocation() {
		return location;
	}

	public void setlocation(String location) {
		this.location = location;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
}
