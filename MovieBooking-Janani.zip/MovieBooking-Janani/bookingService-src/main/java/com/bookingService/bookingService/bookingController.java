package com.bookingService.bookingService;

import java.util.Date;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class bookingController {

	@Autowired
	private bookingService bService;

	@PostMapping(value = "/addshow")
	public ResponseEntity<showModel> addShow(@RequestBody showModel show) {
		return new ResponseEntity<>(bService.addShow(show), HttpStatus.OK);
	}

	@GetMapping(value = "/allshows")
	public ResponseEntity<List<showModel>> getAllShows() {
		return new ResponseEntity<>(bService.getAllShows(), HttpStatus.OK);
	}

	@GetMapping(value = "/show/{showid}")
	public ResponseEntity<showModel> getShowById(@PathVariable("showid") Integer id) {
		return new ResponseEntity<>(bService.getShow(id), HttpStatus.OK);
	}

	@GetMapping(path = "/getshow/{moviename}")
	public ResponseEntity<List<showModel>> findShowByMoive(@PathVariable("moviename") String moviename) {
		return new ResponseEntity<>(bService.findShowByMoive(moviename), HttpStatus.OK);
	}

	@GetMapping(path = "/getshowbytheatre/{theatrename}")
	public ResponseEntity<List<showModel>> findShowByTheatre(@PathVariable("theatrename") String theatrename) {
		return new ResponseEntity<>(bService.findShowByTheatre(theatrename), HttpStatus.OK);
	}

	@PutMapping("/updateshow/{showid}")
	public ResponseEntity<showModel> updateDetails(@PathVariable("showid") Integer id, @Valid @RequestBody showModel show) {
		return new ResponseEntity<>(bService.updateshowDetails(id, show), HttpStatus.OK);
	}

	@DeleteMapping(path = "/show/{showid}")
	public ResponseEntity<Void> deleteShow(@PathVariable("showid") Integer id) {
		bService.deleteShow(id);
		return new ResponseEntity<Void>(HttpStatus.OK);

	}

	@PostMapping(value = "/addbooking")

	public ResponseEntity<bookingModel> addBooking(@Valid @RequestBody bookingModel booking) {
		
		return new ResponseEntity<>(bService.addBooking(booking), HttpStatus.OK);
	}

	@GetMapping(value = "/allbookings")
	public ResponseEntity<List<bookingModel>> getBookings() {
		return new ResponseEntity<>(bService.getBookings(), HttpStatus.OK);
	}

	@GetMapping(value = "/getbooking/{bookingid}")
	public ResponseEntity<bookingModel> getBookingById(@PathVariable("bookingid") Integer id) {
		return new ResponseEntity<>(bService.getBookingbyId(id), HttpStatus.OK);
	}
	@GetMapping(path = "/getbooking/{fromDate}/{toDate}")
	public ResponseEntity<List<bookingModel>> getBookings(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		return new ResponseEntity<>(bService.getReportBydate(fromDate, toDate), HttpStatus.OK);
	}

	@DeleteMapping(path = "/cancelbooking/{bookingid}")
	public ResponseEntity<Void> cancelBooking(@PathVariable("bookingid") Integer id) {
		bService.deleteBooking(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
