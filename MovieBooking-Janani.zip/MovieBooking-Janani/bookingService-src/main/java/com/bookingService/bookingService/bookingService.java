package com.bookingService.bookingService;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class bookingService {
	@Autowired
	private bookingRepository bookrepo;
	@Autowired
	private showRepository showrepo;
	
	
	
	
	public List<showModel> getAllShows(){
        return (List<showModel>) showrepo.findAll();
    }
    
    public Optional<showModel> findShow(int id) {        
        Optional<showModel> show = showrepo.findById(id);
        return show;
    }
    
    public showModel addShow(showModel show) {
    	System.out.println(show.getMovieName());
        return showrepo.save(show);
    }
    
    public showModel updateshowDetails(int id,showModel show) {
        show.setShowId(id);
        return showrepo.save(show);
    }
    
    public showModel getShow(int id) {
		return showrepo.findById(id).get();
	}
    
    public void deleteShow(int id) {      
        showrepo.deleteById(id);        
    }
//    public List<Show> getShowsBymovieId(Movie movieId){
////    	
//   	 return (List<Show>) showrepo.findBymovieId(movieId);
//    }
    
    public List<showModel> findShowByMoive(String moviename) {       
        List<showModel> allshows = getAllShows();
        List<showModel> shows = new ArrayList<>();
        for(showModel show : allshows) {
            if(show.getMovieName().getMoviename().equals(moviename)) {           	
                shows.add(show);
            }
        }
        return shows;     
    }
    
    public List<showModel> findShowByTheatre(String theatrename) {       
        List<showModel> allshows = getAllShows();
        List<showModel> shows = new ArrayList<>();
        for(showModel show : allshows) {
            if(show.getTheatreName().getTheatrename().equals(theatrename)) {
                shows.add(show);
            }
        }
        return shows;     
    }
    public bookingModel addBooking(bookingModel booking) {
    	
		int seatsbooked=booking.getSeatsBooked();
		
		int showid=booking.getShowId().getShowId();		
		Optional <showModel> show=showrepo.findById(showid);
		float price=show.get().getPrice();
		int seatsAvailable=show.get().getSeatsRemaining();
		int remainingseats=seatsAvailable-seatsbooked;
		show.get().setSeatsRemaining(remainingseats);		
		float amount=(seatsbooked*price);
		booking.setAmount(amount);
		return bookrepo.save(booking);
	}
	
	public List<bookingModel> getReportBydate(String fromDate,String toDate){
        List<bookingModel> allbookings= new ArrayList<>();
        List<bookingModel> bookinglist= new ArrayList<>();
        bookrepo.findAll().forEach(allbookings::add);
       
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date startdate = null;
        Date enddate = null;
       
        try {
            startdate = dateFormat.parse(fromDate);
            enddate = dateFormat.parse(toDate);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
       
        for(bookingModel booking : allbookings){
           if((booking.getShowId().getShowdate().after(startdate)&&booking.getShowId().getShowdate().before(enddate))||
                   (booking.getShowId().getShowdate().equals(startdate)||booking.getShowId().getShowdate().equals(enddate))) {
               bookinglist.add(booking);
           }
        }
        return bookinglist;
    }

 	
	public List<bookingModel> getBookings(){
		return (List<bookingModel>) bookrepo.findAll();
	}
	
	public bookingModel getBookingbyId(int id) {
		return bookrepo.findById(id).get();
	}
	
	public void deleteBooking(int id) {
	
		bookingModel booking=getBookingbyId(id);
	    int seatsbooked=booking.getSeatsBooked();
	    showModel show=booking.getShowId();
	    int seatsAvailable=show.getSeatsRemaining();
	    int remainingSeats=(seatsAvailable+seatsbooked);
	   
	    show.setSeatsRemaining(remainingSeats);
		bookrepo.deleteById(id);
	}
}