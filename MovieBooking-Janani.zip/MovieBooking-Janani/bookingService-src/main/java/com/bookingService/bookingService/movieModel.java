package com.bookingService.bookingService;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "movie", schema="onlinemoviebooking")
public class movieModel {
	@Id
	private String moviename;
	private String genre;
	private String director;
	private float rating;
	private String cast;

	public movieModel() {
	}

	public movieModel(String moviename, String genre, String director, String cast, float rating) {
		super();
		this.moviename = moviename;
		this.genre = genre;
		this.director = director;
		this.cast = cast;
		this.rating = rating;
	}

	public String getMoviename() {
		return moviename;
	}

	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
 
	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getCast() {
		return cast;
	}

	public void setCast(String cast) {
		this.cast = cast;
	}
}
