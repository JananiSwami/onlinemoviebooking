package com.bookingService.bookingService;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="booking", schema = "onlinemoviebooking")
public class bookingModel {

	@Id
	@Column(name = "bookingid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingid;

	@OneToOne
	private userModel email;

	@OneToOne
	private showModel showid;

	@NotNull
	private int seatsbooked;

	private float amount;

	public bookingModel() {
			super();
		}

	public Integer getBookingId() {
		return bookingid;
	}

	public void setBookingId(int bookingid) {
		this.bookingid = bookingid;
	}

	public userModel getEmail() {
		return email;
	}

	public void setEmail(userModel email) {
		this.email = email;
	}

	public showModel getShowId() {
		return showid;
	}

	public void setShowId(showModel showid) {
		this.showid = showid;
	}
	public int getSeatsBooked() {
		return seatsbooked;
	}

	public void setSeatsBooked(int seatsbooked) {
		this.seatsbooked = seatsbooked;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

}
