package com.bookingService.bookingService;

import java.sql.Date;
import java.sql.Time;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "showModel", schema = "onlinemoviebooking")
public class showModel {
	
	@Id
	@Column(name = "showid")       	    
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer showId;
	
	@OneToOne
	private movieModel movieName;	
	
	@NotNull
	private float price;

	private Date showdate;
	private Time showtime;
	

	@NotNull
	private int seatsremaining;

    @OneToOne
	private theatreModel theatreName;
    


	public showModel(Integer showId, movieModel movieName, @NotNull float price, Date showdate, Time showtime,
			@NotNull int seatsremaining, theatreModel theatreName) {
		super();
		this.showId = showId;
		this.movieName = movieName;
		this.price = price;
		this.showdate = showdate;
		this.showtime = showtime;
		this.seatsremaining = seatsremaining;
		this.theatreName = theatreName;
	}

	public theatreModel getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(theatreModel theatrename) {
		this.theatreName = theatrename;
	}
	
	public showModel() {
		super();
	}

	public Integer getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public movieModel getMovieName() {
		return movieName;
	}

	public void setMovieName(movieModel moviename) {
		this.movieName = moviename;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Date getShowdate() {
		return showdate;
	}

	public void setDate(Date showdate) {
		this.showdate = showdate;
	}

	public Time getShowtime() {
		return showtime;
	}

	public void getShowtime(Time showtime) {
		this.showtime = showtime;
	}

	public int getSeatsRemaining() {
		return seatsremaining;
	}

	public void setSeatsRemaining(int seatsremaining) {
		this.seatsremaining = seatsremaining;
	}	
}
