package com.movieService.movieService;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class movieController {
	@Autowired
	public movieService mService;

	@GetMapping("/viewmovies")
	public ResponseEntity<List<movieModel>> getMoviesDetails() {
		return new ResponseEntity<>(mService.getMovieDetails(), HttpStatus.OK);
	}

	@PostMapping("/newmovie")
	public ResponseEntity<movieModel> addUser(@Valid @RequestBody movieModel movie) {

		return new ResponseEntity<>(mService.addMovie(movie), HttpStatus.OK);
	}

	@GetMapping(path = "/movie/{movieName}")
	public ResponseEntity<Optional<movieModel>> getMovieByName(@PathVariable("movieName") String title) {
		return new ResponseEntity<>(mService.getMovieByName(title), HttpStatus.OK);
	}

	@GetMapping("/movie/director/{director}")
	public ResponseEntity<List<movieModel>> getMovieByDirector(@PathVariable("director") String director) {
		return new ResponseEntity<>(mService.getMovieByDirector(director), HttpStatus.OK);
	}
	
	@GetMapping("/movie/genre/{genre}")
	public ResponseEntity<List<movieModel>> getMovieByGenre(@PathVariable("genre") String genre) {
		return new ResponseEntity<>(mService.getMovieByGenre(genre), HttpStatus.OK);
	}

	@PutMapping("/movie/{movieName}")
	public ResponseEntity<movieModel> updateDetails(@Valid @RequestBody movieModel movie) {
		return new ResponseEntity<>(mService.updateDetails(movie), HttpStatus.OK);
	}

	@DeleteMapping(path = "/movie/{movieName}")
	public ResponseEntity<Void> deleteMovie(@PathVariable("movieName") String movieName) {
		mService.deleteByMovieName(movieName);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
