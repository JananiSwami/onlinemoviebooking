package com.movieService.movieService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class movieService {
	@Autowired
	public movieRepository repo;

	public movieModel addMovie(movieModel movie) {
		return repo.save(movie);
	}

	public List<movieModel> getMovieDetails() {
		List<movieModel> movies = new ArrayList<>();
		repo.findAll().forEach(movies::add);
		return movies;
	}

	public Optional<movieModel> getMovieByName(String title) {

		Optional<movieModel> movies = repo.findById(title);
		return movies;
	}

	public List<movieModel> getMovieByDirector(String director) {
		return (List<movieModel>) repo.findByDirector(director);
	}


	public List<movieModel> getMovieByGenre(String genre) {
		return (List<movieModel>) repo.findByGenre(genre);
	}
	public void deleteByMovieName(String MovieName) {
		repo.deleteById(MovieName);
	}

	public movieModel updateDetails(movieModel movie) {
		return repo.save(movie);
	}
}
