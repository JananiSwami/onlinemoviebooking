package com.TheatreService.theatreService;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface theatreRepository extends CrudRepository<theatreModel, String>{
	public List<theatreModel> findByLocation(String location); 	
}