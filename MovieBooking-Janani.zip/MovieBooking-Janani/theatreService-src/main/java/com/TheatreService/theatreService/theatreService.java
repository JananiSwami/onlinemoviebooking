package com.TheatreService.theatreService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class theatreService {
	@Autowired
	public theatreRepository repo;

	public theatreModel addTheatre(theatreModel theatre) {
		return repo.save(theatre);
	}

	public List<theatreModel> getTheatreDetails() {
		List<theatreModel> theatres = new ArrayList<>();
		repo.findAll().forEach(theatres::add);
		return theatres;
	}

	public List<theatreModel> getTheatreByLocation(String location) {
		return (List<theatreModel>) repo.findByLocation(location);
	}
	
	
	public Optional<theatreModel> getTheatreByName(String theatrename) {
		Optional<theatreModel> theatres = repo.findById(theatrename);
		return theatres;
	}

	public void deleteByTheatreName(String theatrename) {
		repo.deleteById(theatrename);
	}

	public theatreModel updateDetails(theatreModel theatre) {
		return repo.save(theatre);
	}
}
