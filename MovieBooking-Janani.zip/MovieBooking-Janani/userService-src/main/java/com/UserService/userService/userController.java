package com.UserService.userService;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class userController {
	
	@Autowired
    private userService uService;
	     
	@GetMapping("/admin/users")           
    public ResponseEntity<List<userModel>> getUsersDetails(){
    return new ResponseEntity<>(uService.getUserDetails(),HttpStatus.OK);
   }
	
//	@GetMapping("/allusers")
//    public List<userModel> getAllUser(){
//                return uService.getAllUser();
//    }
   
   @PostMapping( "/newusers")
   public ResponseEntity<userModel> addUser(@Valid @RequestBody userModel user){
	    
       return new ResponseEntity<>(uService.addUser(user),HttpStatus.OK);
   }
   
   @PostMapping( "/admin/newAdmin")
   public ResponseEntity<userModel> addAdmin(@Valid @RequestBody userModel user){
	   return new ResponseEntity<>(uService.addUser(user),HttpStatus.OK);
   }
   
   @DeleteMapping(path = "/user/{email}")
   public ResponseEntity <Void> deleteUser(@PathVariable("email") String email){
	   uService.deleteByEmail(email);
   return new ResponseEntity<Void>(HttpStatus.OK);      
   }
   
   @GetMapping(path = "/user/{email}")
   public ResponseEntity<Optional<userModel>> getUserByEmail(@PathVariable("email") String email){
       return new ResponseEntity<>(uService.findUser(email),HttpStatus.OK);      
   }
   
   @PutMapping("/user/{email}")
   public ResponseEntity<userModel> updateDetails(@Valid @RequestBody userModel user){
       return new ResponseEntity<>(uService.updateDetails(user), HttpStatus.OK);
   }
   
   @PostMapping("/login")
   public ResponseEntity<String> login(@Valid @RequestBody userLogin loginuser){
        return new ResponseEntity<>(uService.login(loginuser), HttpStatus.OK);   
   }
}
