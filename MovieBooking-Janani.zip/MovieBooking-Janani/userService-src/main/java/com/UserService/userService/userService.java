package com.UserService.userService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class userService {

	@Autowired
	public userRepository repo;

	public List<userModel> getUserDetails() {
		List<userModel> users = new ArrayList<>();
		repo.findAll().forEach(users::add);
		return users;
	}
	
//
//	public List<userModel> getAllUser(){
//        List<userModel> users= (List<userModel>) repo.findAll();
//         return users;
//    }
	public userModel addUser(userModel user) {
		user.setRoleName("customer");
		return repo.save(user);
	}
	
	public userModel addAdmin(userModel user) {
		user.setRoleName("admin");
		return repo.save(user);
	}

	public void deleteByEmail(String email) {
		repo.deleteById(email);
	}

	public userModel updateDetails(@Valid userModel user) {
		return repo.save(user);
	}

	public Optional<userModel> findUser(String id) {

		Optional<userModel> users = repo.findById(id);
		return users;
	}

	public String login(userLogin loginuser) {
		userModel user = null;
		Optional<userModel> optuser = repo.findById(loginuser.getEmail());

		if (optuser.isPresent()) {
			user = optuser.get();
			if (user.getPassword().equals(loginuser.getPassword())) {

				return "successfully login";
			}

			else {
				return "failed login";

			}
		} 
		else {
			return "No user present";
		}
	}
}